﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace TCaa.filehandling
{
    class CLSFHaa
    {
        
        public static void Main()
        {
            byte[] byterr = Encoding.UTF8.GetBytes("Hot drinks\nCoffee\nTea\nmilk\n");
            FileStream fs = new FileStream("drinks.txt", FileMode.Create);
            fs.Write(byterr, 0, byterr.Length);
            fs.Close();
            Console.WriteLine("Successfully Created new file");
        }
    }
}
/*
 Successfully Created new file
*/