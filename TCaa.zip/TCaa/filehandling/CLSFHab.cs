﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text;


namespace TCaa.filehandling
{
    class CLSFHab
    {
        public static void Main()
        {
            byte[] bytarr = Encoding.UTF8.GetBytes("Cool drinks\n7up\nCoke\nPepsi\n");
            FileStream fs = new FileStream("drinks.txt", FileMode.Append);
            fs.Write(bytarr, 0, bytarr.Length);
            fs.Close();
            Console.WriteLine("Successfully updated a file");
        }
    }
}
/*
 Successfully updated a file
*/