﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text;
using System.IO;

namespace TCaa.filehandling
{
    class CLSFHac
    {public static void Main()
        {
            FileStream fs = new FileStream("drinks.txt", FileMode.Open);
            Console.WriteLine("File Size(in bytes):\n");
            Console.WriteLine(fs.Length);

            byte[] bytarry = new byte[fs.Length];
            fs.Read(bytarry, 0, bytarry.Length);
            fs.Close();

            Console.WriteLine("File Content:\n");
            Console.WriteLine(Encoding.UTF8.GetString(bytarry));

        }
    }
}
/*
 File Size(in bytes):

54
File Content:

Hot drinks
Coffee
Tea
milk
Cool drinks
7up
Coke
Pepsi
*/