﻿using System;
using System.Collections;
//Example for hashtable (a,b,c)
namespace TCaa.vararray
{
    class CLShtaa
    {
        static void Main()
        {
            Hashtable HTobj = new Hashtable();
            HTobj["Box"] = 11;
            HTobj[22] = "Fox";

            Console.WriteLine(HTobj["Box"]);
            Console.WriteLine(HTobj["Fox"]);
            //Ans:11
            foreach (var v1 in HTobj.Keys)
            Console.WriteLine(HTobj[v1]);
        }
    }
}
/*
 11

Fox
11
*/