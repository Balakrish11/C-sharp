﻿using System;
using System.Collections;

namespace TCaa.vararray
{
    class CLSbitarray1
    {
        static void Display(BitArray BAobj)
        {
            foreach(bool b in BAobj)
            {
                Console.WriteLine(b ? 1 : 0);
            }
            Console.WriteLine("\n");
        }
        static void Main()
        {
            BitArray BAobjA = new BitArray(6);
            BAobjA[0] = true;
            BAobjA[2] = true;
            BAobjA.Set(5, true);
            Display(BAobjA);

            BitArray BAobjB = new BitArray(6);
            Display(BAobjB);
            BAobjB[2] = true;
            BAobjA.And(BAobjB);
            Display(BAobjA);

        }
    }
}
/* OP:
1
0
1
0
0
1


0
0
0
0
0
0


0
0
1
0
0
0
*/