﻿using System;
using System.Collections;
//example for add range(array)
namespace TCaa.vararray
{
    class CLSaryaddrange
    {
        public static void Main()
        {
            ArrayList ALobja = new ArrayList();
            ALobja.Add("Box");
            ALobja.Add(11);

            ArrayList ALobjb = new ArrayList();

            ALobja.Add(4.2);
            ALobjb.Add(true);
            ALobja.AddRange(ALobjb);
            foreach (var v1 in ALobja)
                Console.WriteLine(v1);

        }
    }
}
/*
 Box
11
4.2
True
Press any key to continue . . .
*/