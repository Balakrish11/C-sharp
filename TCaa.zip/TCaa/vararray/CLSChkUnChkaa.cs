﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa.vararray
{
    class CLSChkUnChkaa
    {
        public static void Main()
        {
            int x = int.MinValue;
            int y = int.MaxValue;

            Console.WriteLine(x);// -2147483648
            Console.WriteLine(--x);//2147483647(-2147483648 -1 ->2147483647)

            Console.WriteLine(y);//2147483647
            Console.WriteLine(++y);//-2147483648(2147483647 +1 ->-2147483648)


        }
    }
}
/*
 -2147483648
2147483647

2147483647
-2147483648
*/