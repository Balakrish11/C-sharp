﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Title: Example for without 'Checked' block
//'Unchecked' block disable validation strict mode

namespace TCaa.vararray
{
    class CLSChkUnChkac
    {
        public static void Main()
        {
            int x = int.MinValue;
            int y = int.MaxValue;

            Console.WriteLine(x);
            Console.WriteLine(y);

            unchecked
            {
                Console.WriteLine(--x);
            }

            unchecked
            {
                Console.WriteLine(++y);
            }
        }
    }
}
/*
 Output:
 -2147483648
2147483647
2147483647
-2147483648
*/

