﻿using System;
using System.Collections.Generic;
//example for Dictionary object
//Dictionary key can handle from any one data type

namespace TCaa.vararray
{
    class CLSDictionary
    {
        public static void Main(string[]args)
        {
            Dictionary<string, string> SDobj = new Dictionary<string, string>();
            SDobj.Add("Box", "11");
            SDobj.Add("Fox", "22");

            foreach(string strkey in SDobj.Keys)
            {
                Console.WriteLine(strkey);
            }
            foreach (string strval in SDobj.Values)
                Console.WriteLine(strval);
        }
    }
}
/*
Box
Fox
11
22
*/