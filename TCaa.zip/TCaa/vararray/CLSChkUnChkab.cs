﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Title: Example for without 'checked' block
//'Checked' block enable validation strict mode

namespace TCaa.vararray
{
    class CLSChkUnChkab
    {
        public static void Main()
        {
            int x = int.MinValue;
            int y = int.MaxValue;
            checked
            {
                //Console.WriteLine(--x);//OverflowException
            }
            checked
            {
              //  Console.WriteLine(++y);//OverflowException
            }
        }
    }
}