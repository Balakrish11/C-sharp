﻿using System;
using System.Collections;

namespace TCaa.vararray
{
    class CLSarybitarraySC
    {
        public static void Main()
        {
            BitArray BAobj = new BitArray(6);
            BAobj[0] = true;
            BAobj[2] = true;

            BAobj.Set(5, true);
            Console.WriteLine(BAobj.Count);
            int i = 0;
            foreach(bool b in BAobj)
            {
                if (b)
                    i++;
                Console.WriteLine(i);
            }

        }
    }
}
/*
 OP:
 6
1
1
2
2
2
3
*/