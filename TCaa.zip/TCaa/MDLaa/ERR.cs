﻿using System;
namespace TCaa
{
    class ERR

    {
        public static void Main()
        {
            Console.WriteLine("Enter following inputs for exam Result");
            String ip = null;
            Console.Write("\n Roll number:\t");
            ip = Console.ReadLine();
            int rno = 0;
            int.TryParse(ip, out rno);
            Console.Write("\nStudent name:\t");
            String sname = Console.ReadLine();
            Console.Write("\nMark-1:\t");
            ip = Console.ReadLine();
            double m1 = 0;
            double.TryParse(ip, out m1);
            Console.Write("\nMark-2:\t");
            ip = Console.ReadLine();
            double m2 = 0;
            double.TryParse(ip, out m2);
            double total = (m1 + m2), avg = (m1 + m2) / 2;
            bool result = (m1 > 34.4 && m2 > 34.4);
            Console.WriteLine("Roll.no:\t" + rno);
            Console.WriteLine("Name:\t" + sname);
            Console.WriteLine("Mark-1:\t" + m1);
            Console.WriteLine("Mark-2:\t" + m2);
            Console.WriteLine("Total:\t" + total);
            Console.WriteLine("Average:\t" + avg);
            Console.WriteLine("Result:\t" + (result ? "Pass":"Fail"));
          }
    }

}
/*
Enter following inputs for exam Result

 Roll number:   1001

Student name:   Aarthi

Mark-1: 100

Mark-2: 100
Roll.no:        1001
Name:   Aarthi
Mark-1: 100
Mark-2: 100
Total:  200
Average:        100
Result: Pass
Press any key to continue . . .
*/

