﻿using System;
namespace TCaa.MDLaa
{
    class CLSHomeaa
    {
        public static void Main()
        {
            Console.WriteLine("Choose execute App:\n");
            Console.WriteLine("1.Employee Allowances");
            Console.WriteLine("2.Exam Result");
            Console.WriteLine("3.Salary Tax");
            Console.WriteLine("Enter App no. between 1 to 3");
            int i = 0;
            int.TryParse(Console.ReadLine(), out i);
            if (!(i >= 1 && i <= 3))
            {
                Console.WriteLine("Invaild App no.");
                return;
            }
            if (i == 1)
            {
                EAA.Main();
                return;
            }
            if (i == 2)
            {
                ERR.Main();
                return;
            }

            STA.Main();
        }
    }
}

/*
Choose execute App:

1.Employee Allowances
2.Exam Result
3.Salary Tax
Enter App no. between 1 to 3
4
Invaild App no.
Press any key to continue . . .
*/



