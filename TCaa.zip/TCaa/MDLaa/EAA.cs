﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa

{
    class EAA

    {
        public static void Main()
        {
            Console.WriteLine("Enter Employee Allowences");
            String ip = null;
            Console.Write("ID:\t");
            ip = Console.ReadLine();
            int eid = 0;
            int.TryParse(ip, out eid);

            Console.Write("Name:\t");
            String ename = Console.ReadLine();

            Console.Write("Salary:\t");
            ip = Console.ReadLine();

            double esal= 0;
            double.TryParse(ip, out esal);

            double hra = esal * (20.0 / 100);
            double da = esal * (15.0 / 100);
            double pf = esal * (35.0 / 100);
            double gpay = esal + hra + da;
            double npay = gpay - pf;

            Console.WriteLine("Employee Salary Allowences");
            Console.WriteLine("ID:" + eid);
            Console.WriteLine("Name:" + ename);
            Console.WriteLine("Salary:" + esal);
            Console.WriteLine("HRA:" + hra);
            Console.WriteLine("DA:" + da);
            Console.WriteLine("PF:" + pf);
            Console.WriteLine("Gpay:" + gpay);
            Console.WriteLine("Npay:" + npay);



        }

    }
}
/*
 Enter Employee Allowences
ID:     1001
Name:   suthakar
Salary: 100000
Employee Salary Allowences
ID:1001
Name:suthakar
Salary:100000
HRA:20000
DA:15000
PF:35000
Gpay:135000
Npay:100000
Press any key to continue . . .


 */
