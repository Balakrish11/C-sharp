﻿using System;

//Exception Handling

namespace TCaa
{
    class EHaa
    {
        public static void Main()
        {
            try
            {
                Console.WriteLine("Welcom");
                int i = 10, j = 0;
                Console.WriteLine(i / j);
                Console.WriteLine("Thanks");

            }catch (Exception e)
            {
                Console.WriteLine("err.:" + e.Message);

            }
            Console.WriteLine("Visit Again");
        }
    }
}
/*
Welcom
err.:Attempted to divide by zero.
Visit Again
Press any key to continue . . .
 */
