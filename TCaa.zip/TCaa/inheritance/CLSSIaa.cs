﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa.inheritance
{
    class CLSSIaa
    {
        public CLSSIaa()
        {
            Console.WriteLine("Constructor: CLSSIaa");
        }
        ~CLSSIaa()
        {
            Console.WriteLine("Destructor: CLSSIaa");
        }
    }
    class CLSSIab : CLSSIaa
    {
    public CLSSIab()
        {
            Console.WriteLine("Constructor: CLSSIab");
        }
        ~CLSSIab()
        {
            Console.WriteLine("Destructor: CLSSIab");

        }
        class CLSSIac
        {
            public static void Main()
            {
                new CLSSIab();
            }

        }
    }
}
/*
 OP:
Constructor: CLSSIaa
Constructor: CLSSIab

Destructor: CLSSIab
Destructor: CLSSIaa
Press any key to continue . . .
*/

