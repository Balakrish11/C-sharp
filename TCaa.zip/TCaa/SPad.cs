﻿using System;

namespace TCaa
{
    class SPad
    {
        public static void Main()
        {
            UDCLMath umath = new UDCLMath();
            Console.WriteLine(umath.udmSum(1, 9));
            umath.udmMultiply(2, 8);
            Console.WriteLine(UDCLMath.udMinus(6, 2));
            UDCLMath.udmdivide(20, 3);
        }
    }
}

/*
Output:
10
16
4
6
Press any key to continue . . .
 */
