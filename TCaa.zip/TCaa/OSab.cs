﻿using System;

namespace TCaa
{
    class OSab
    {
        public static void Main()
        {
            Console.WriteLine("Welcome");
            Console.WriteLine("Sun");
            Console.Write("Mon");
            Console.Write("Tus");
            Console.WriteLine("Wed");
            Console.Write("Thu");
            Console.WriteLine("Fri");
            Console.WriteLine("Sat");
            Console.Write("Thanks");
        }
    }
/*
 Welcome
Sun
MonTusWed
ThuFri
Sat
ThanksPress any key to continue . . .
*/


}
