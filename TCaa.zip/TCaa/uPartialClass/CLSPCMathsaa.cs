﻿using System;

namespace TCaa.uPartialClass
{
   partial class CLSPCMathaa
    {
        public int j = 2;
        public void uMinus(int x, int y)
        {
            Console.WriteLine(x - y);
        }

    }
}
