﻿using System;

namespace TCaa.uPartialClass
{
   partial class CLSPCMathaa
    {
        public int i = 7;
        public int uSum(int x,int y)
        {
            return x + y;
        }
    }
}
