﻿using System;

namespace TCaa
{
   public class UDCLMath
    {
      public int udmSum(int x,int y)
        {
            return x + y;
        }  
        public static int udMinus(int x,int y)
        {
            return x-y;
        }
        public  void udmMultiply(int x,int y)
        {
            Console.WriteLine(x * y);
        }
        public static void udmdivide(int x,int y)
        {
            Console.WriteLine(x / y);
        }
        }


    }


