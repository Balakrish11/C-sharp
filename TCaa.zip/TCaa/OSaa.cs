﻿using System;
namespace TCaa
{
    class OSaa

    {
        static void Main(String[]args)
        {
            Console.WriteLine(4 + 5 + 7);
        }
    }
}
/*
 Output:
16
Press any key to continue . . .
*/