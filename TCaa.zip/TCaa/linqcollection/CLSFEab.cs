﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa.linqcollection
{
    class CLSFEab
    {
        public static void Main()
        {
            List<CLSERaa> Lst = new List<CLSERaa>()
            {
                new CLSERaa {rno=1001,sname="x5",m1=56.5,m2=63},
                new CLSERaa {rno=1002,sname="x3",m1=98,m2=20},
                new CLSERaa {rno=1003,sname="x1",m1=45.5,m2=52},
             };
            Array.ForEach(Lst.ToArray(), row => Console.WriteLine(
                "{0,4}\t{1,5}\t{2,5}\t{3,5}\t{4,6}\t{5,5}\t{6,4}\n",
                row.rno,row.sname,row.m1,row.m2,row.total,row.avg,row.result));
            
        }
    }
}
/*
 1001       x5    56.5      63    119.5  59.75   Pass

1002       x3      98      20      118     59   Fail

1003       x1    45.5      52     97.5  48.75   Pass
*/