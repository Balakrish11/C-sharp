﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa.abclass
{
    class CLSDLgaa
    {
        delegate void uCalcu(int i, int j);
        public static void Main()
        {
            uCalcu uSum = delegate (int i, int j)
            {
                Console.WriteLine(i + j);
            };
            uCalcu uDiv = delegate (int i, int j)
            {
                Console.WriteLine(i /j);
            };
            uCalcu uMul = delegate (int i, int j)
            {
                Console.WriteLine(i *j);
            };
            uSum(1, 5);
            uDiv(10, 3);
            uMul(7, 2);


        }
    }
}
/*
 6
3
14
*/