﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa.abclass

    {
   abstract class Calcu
{
        public abstract void uDiv(int x, int y);
        public int uMul(int x,int y)
        {
            return x * y;
        }
        class Calacb:Calcu
        {
            public override void uDiv(int x, int y)
            {
                Console.WriteLine(x / y);
            }
        }
        class CLSAbstaa
        {
            public static void Main()
            {
                Calcu obj = new Calacb();
                obj.uDiv(10,3);
                Console.WriteLine(obj.uMul(5, 9));
                Calacb obj2 = new Calacb();
                obj2.uDiv(20, 7);
                Console.WriteLine(obj2.uMul(9, 4));
            }

        }
}
}
/*
3
45
2
36
*/
