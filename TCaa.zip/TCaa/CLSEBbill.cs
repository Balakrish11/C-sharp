﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa
{
    class CLSEBbill

    {
        public static void Main()
        {
            int cpr = 0;

            int ccr = 0;
            int cnr = (cpr - ccr);



            if (cpr > ccr)
            {
                Console.WriteLine("Invaild reading");
                return;
            }
        }
    }
}

