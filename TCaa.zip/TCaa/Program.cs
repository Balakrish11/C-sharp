﻿using System;

namespace NSA
{
    class TCaa
    {
       public static void Main(string[] args)
        {
            string s = "fox";
            int i = 0;
            i = int.Parse(s);
            Console.WriteLine(i);
            Console.WriteLine(s);
            
        }
    }
}
