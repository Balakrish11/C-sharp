﻿using System;

namespace TCaa
{
    class CLSAtaa
    {
        public  static void Main()
        {
            Console.WriteLine("ab\ncd");
            Console.WriteLine("ab\\ncd");
            Console.WriteLine(@"ab\ncd");//@ identifier
        }
    }
}
/*
 OP:
ab
cd
ab\ncd
ab\ncd
*/
