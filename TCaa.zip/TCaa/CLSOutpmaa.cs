﻿using System;
/*
  Example for Out Parameter Modifier
 */
namespace TCaa
{
    class CLSOutpmaa
    {
        public static void uSum(int i,int j, out int k)
        {
            k = i + j;
        }
        public static void uFLNames(String fullname,out String fname,out String Lname)
        {
            int bsi = fullname.LastIndexOf(" ");
            if (bsi==-1)
            {
                fname = fullname;
                Lname = null;
                return;
               
            }
            fname = fullname.Substring(0, bsi).Trim();
            Lname = fullname.Substring(bsi).Trim();

        }
        public static void Main()
        {
            int x = 0;
            uSum(2, 5, out x);
            Console.WriteLine(x);
            String fullname = "raja ragu raman", SonName = null, fatherName = null;
            uFLNames(fullname, out SonName, out fatherName);
            Console.WriteLine(SonName);
            Console.WriteLine(fatherName);

                
        }
    }
}
/*
 OutPut:
 7
raja ragu
raman

*/