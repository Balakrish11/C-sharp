﻿using System;
//Foreach Loop
namespace TCaa
{
    class CLSSUMaa
    {
        public static void Main(string[] args)
        {
            if(args.Length==0)
            {
                Console.WriteLine("Invaild arguments\n");
                return;
            }
            double i = 0, j = 0;
            foreach(string s in args)
            {
                i = 0;
                double.TryParse(s, out i);
                j += i;
            }
            Console.WriteLine(j);
        }
        //OutPut:Invaild arguments





    }
}
