﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using uSc = System.Console;

namespace TCaa.gcpeak
{
    class CLSANaa
    {
        public static void Main()
        {
            uSc.WriteLine("Hi");
            uSc.WriteLine(9 + 7);
        }
    }
}
/*
 Hi
16
*/
