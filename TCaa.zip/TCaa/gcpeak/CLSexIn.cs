﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa.gcpeak
{
    class CLSexIn
    {
        public static void Main()
        {
            Int32 i = 5;
            Console.WriteLine(i);
        }
    }
}
/*
 5
 */