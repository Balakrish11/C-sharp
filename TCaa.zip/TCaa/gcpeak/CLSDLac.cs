﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Multi Cast Delegate

namespace TCaa.gcpeak
{
    class CLSDLac
    {
        delegate void uCalc(int i, int j);

        public static void uSum(int x, int y)
        {
            Console.WriteLine("{0}+{1}={2}", x, y, x + y);
        }
        public static void uMinus(int x, int y)
        {
            Console.WriteLine("{0}-{1}={2}", x, y, x - y);
        }
        public static void Main()
        {
            uCalc uc = uSum;
            uc += uMinus;
            uc(5, 2);

            Console.WriteLine("\n");
            uc -= uSum;
            uc(8, 3);
            Console.WriteLine("\n");
            uc = uSum + uc;
            uc(5, 4);
        }
    }
}

/*
Output:
5+2=7
5-2=3


8-3=5


5+4=9
5-4=1
*/