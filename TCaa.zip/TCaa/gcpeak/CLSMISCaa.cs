﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa.gcpeak
{
    class CLSMISCaa
    {
        public static void Main()
        {
            decimal d = 5.9m;
            Console.WriteLine(d);
            Console.WriteLine("box\rf");
        }
    }
}
/*
5.9
fox
    */

