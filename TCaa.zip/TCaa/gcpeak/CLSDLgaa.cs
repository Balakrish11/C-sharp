﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa.gcpeak
{
    class CLSDLgaa
    {
        delegate void uShow();
        public void uExhibit()
        {
            Console.WriteLine("Method:uExhibit");
        }
        public static void uDisplay()
        {
            Console.WriteLine("Method:uDisplay");
        }
        public static void Main()
        {
            uShow us = new CLSDLgaa().uExhibit;
            us();
            us = uDisplay;
            us();

        }
    }
}
/*
Method:uExhibit
Method:uDisplay
*/