﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa.gcpeak
{
    class CLSgcs
    {
        public static void Main()
        {
            Stack<int> skobj = new Stack<int>();
            skobj.Push(2);
            skobj.Push(4);
            skobj.Push(6);
            skobj.Push(8);
            skobj.Push(10);

            foreach (int i in skobj)
                Console.WriteLine(i);
            Console.WriteLine("\n" + skobj.Pop());
            Console.WriteLine(skobj.Peek() + "\n");
            int[] x = { 9, 7, 5 };
            skobj = new Stack<int>(x);
            foreach (int j in skobj)
                Console.WriteLine(j);

        }
    }
}
