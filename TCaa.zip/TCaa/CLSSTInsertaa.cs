﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa
{
    class CLSSTInsertaa
    {
        public static void Main()
        {
            CLSSTaa st = new CLSSTaa();
            st.ename = "x9";
            st.esal = 90000;
            DataCLSSTaaDataContext dL = new DataCLSSTaaDataContext(CLSSCnStr.forbalasdb);
            dL.GetTable<CLSSTaa>().InsertOnSubmit(st);
            dL.SubmitChanges();
            Console.WriteLine("1 Row affected");
        }
    }
}
/*
Output:
1 Row affected
*/
