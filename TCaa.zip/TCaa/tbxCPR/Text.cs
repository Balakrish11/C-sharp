﻿namespace tbxCPR
{
    internal class Text
    {
    }
}