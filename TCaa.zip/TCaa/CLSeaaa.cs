﻿using System;

namespace TCaa
{
    class CLSeaaa
    {
        public CLSeaaa()
        {
            Console.WriteLine("Constructor :CLSSeaa");
        }
        ~CLSeaaa()
        {
            Console.WriteLine("Destructor:CLSSeaa");

        }
    }
    sealed class CLSSeaab : CLSeaaa
    {
        public CLSSeaab()
        {
            Console.WriteLine("Constructor:CLSSeaab");
        }
        ~CLSSeaab()
        {
            Console.WriteLine("Destructor :CLSSeaab");
        }
    }


    class CLSSeaac
    {
        public CLSSeaac()
        {
            Console.WriteLine("Constructor: CLSSeaac");
        }
        ~CLSSeaac()
        {
            Console.WriteLine("Destructor:CLSSeaac");
        }
        class CLSSealedaa
        {
            public static void Main()
            {
                new CLSSeaab();
            }
        }

    }
}
/*
 OutPut:
 Constructor :CLSSeaa
Constructor:CLSSeaab
Destructor :CLSSeaab
Destructor:CLSSeaa
Press any key to continue . . .
*/
