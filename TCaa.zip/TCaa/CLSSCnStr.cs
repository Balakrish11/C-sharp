﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa
{
    class CLSSCnStr
    {
        public static string forbalasdb
        {

            get
            {
                return "data source=.;initial catalog = balasdb;integrated security = true;";

            }

        }
    }
}

