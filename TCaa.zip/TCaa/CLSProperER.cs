﻿using System;
//Develop properties feature in Console App

namespace TCaa
{
    class CLSProperER //Exam Result
    {
        private int _rno;
        private string _sname;
        private double _m1 = 0, _m2 = 0;

        public int RNo //property Namee
        {
            get
            {
                return _rno;//return instance private variable
            }
            set
            {
                _rno = value;//"value" reserved word use only in set Accessor
            }
        }
        public string sname
        {
            get
            {
                return _sname;
            }
            set
            {
                _sname = value;
            }
        }
        public double M1
        {
            get
            {
                return _m1;
            }
            set
            {
                _m1 = value;
            }
        }
        public double M2
        {
            get
            {
                return _m2;
            }
            set
            {
                _m2 = value;
            }
        }
        public double Total
        {
            get
            {
                return _m1 + _m2;
            }
       }

        public double Avg
        {
            get
            {
                return Total / 2;
            }
        }
        public string Result // Read only Property
        {
            get
            {
                return _m1 > 34.4 && _m2 > 34.4 ? "Pass" : "Fail";
             }
        }
        class CLSPropaa
        {
            public static void Main()
            {
                CLSProperER er = new CLSProperER();
                er.RNo = 1001;
                er.sname = "xx";
                er.M1 = 56.5;
                er.M2 = 63;
                Console.WriteLine(er.RNo);
                Console.WriteLine(er.sname);
                Console.WriteLine(er.M1);
                Console.WriteLine(er.M2);
                Console.WriteLine(er.Total);
                Console.WriteLine(er.Avg);
                Console.WriteLine(er.Result);

            }

        }
    }
}
/*
Output:
1001
xx
56.5
63
119.5
59.75
Pass
*/