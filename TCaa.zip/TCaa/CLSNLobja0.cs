﻿using System;
//Title: Anonymous (Nameless/temporary) object
namespace TCaa
{
    class CLSNLobja0
    {
        public int x = 5;
        public static int y = 10;

        public static int uSum(int i, int j)
        {
            return i + j;
        }
        public static void uMinus(int i, int j)
        {
            Console.WriteLine(i - j);
        }
        public void uMultiply(int i, int j)
        {
            Console.WriteLine(i * j);
        }
        public int uDivide(int i, int j)
        {
            return i / j;
        }

        
            public static void Main() { 

            Console.WriteLine(new CLSNLobja0().x);
            Console.WriteLine(new CLSNLobja0().uDivide(20,3));
            new CLSNLobja0().uMultiply(4,7);

            Console.WriteLine(CLSNLobja0.y);
            Console.WriteLine(CLSNLobja0.uSum(9,5));
            CLSNLobja0.uMinus(6,2);
          }
     }
}
/*
OutPut:
5
6
28

10
14
4
*/