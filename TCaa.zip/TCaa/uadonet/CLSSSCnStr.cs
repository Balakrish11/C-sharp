﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace TCaa.uadonet
{
    public class CLSSSCnStr
    {
        public static string cnStr = ""+ 
            "data source=.;" +
            "initial catalog=balasdb;" +
            "integrated security=true;";

    }
}
