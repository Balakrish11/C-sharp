﻿using System;
using System.Data;
using System.Data.SqlClient;
namespace TCaa.uadonet
{
    class CLSSSSelaa
    {
        public static void Main()
        {
            SqlConnection sqlcnn = null;
            SqlCommand sqlcmd = null;
            SqlDataAdapter sqlda = null;
            DataSet ds = null;
            DataTable dt = null;

            string qrySel = null;
            try
            {
                qrySel = "select * from eatbl";
                Console.WriteLine("\nEmployee Salary Allowances table Columns name");

                sqlcnn = new SqlConnection(CLSSSCnStr.cnStr);
                sqlcnn.Open();

                sqlcmd = new SqlCommand(qrySel, sqlcnn);
                sqlda = new SqlDataAdapter(sqlcmd);

                ds = new DataSet();
                sqlda.Fill(ds, "eatbl");
                dt = ds.Tables["eatbl"];

                Console.WriteLine("No. of Columns:" + dt.Columns.Count);
                Console.WriteLine("No. of rows:" + dt.Rows.Count);
            }
            catch (Exception e)
            {
                Console.WriteLine("Err.:" + e.Message);
            }
            finally
            {
                sqlcnn.Close();
            }
        }

      }        
  }
/*
 Output:
 Employee Salary Allowances table Columns name
No. of Columns:8
No. of rows:4
*/
