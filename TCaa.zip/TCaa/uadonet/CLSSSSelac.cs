﻿using System;
using System.Data;
using System.Data.SqlClient;

/*
example for  how to display specific records from SQL Server table
in Console App using C#
*/


namespace TCaa.uadonet
{
    class CLSSSSelac
    {
        public static void Main()

        {
            SqlConnection sqlcnn = null;
            SqlCommand sqlcmd = null;
            SqlDataAdapter sqlda = null;
            DataSet ds = null;
            DataTable dt = null;

            string qrySel = null;
            try
            {
                qrySel = "select * from eatbl";
                Console.Write("\nEmployee Salary Allowances ");
                Console.WriteLine("for show specific rows");

                sqlcnn = new SqlConnection(CLSSSCnStr.cnStr);
                sqlcnn.Open();

                sqlcmd = new SqlCommand(qrySel, sqlcnn);
                sqlda = new SqlDataAdapter(sqlcmd);

                ds = new DataSet();
                sqlda.Fill(ds, "eatbl");
                dt = ds.Tables["eatbl"];

                Console.WriteLine("\n1St row (index:0),7 columns value");
                Console.Write(dt.Rows[0][0] + "\t");
                Console.Write(dt.Rows[0][1] + "\t");
                Console.Write(dt.Rows[0][2] + "\t");
                Console.Write(dt.Rows[0][3] + "\t");
                Console.Write(dt.Rows[0][4] + "\t");
                Console.Write(dt.Rows[0][5] + "\t");
                Console.Write(dt.Rows[0][6] + "\t");
                Console.WriteLine(dt.Rows[0][7]);

                Console.WriteLine("\n3rd row (index:0),7 columns value");
                Console.Write(dt.Rows[2][0] + "\t");
                Console.Write(dt.Rows[2][1] + "\t");
                Console.Write(dt.Rows[2][2] + "\t");
                Console.Write(dt.Rows[2][3] + "\t");
                Console.Write(dt.Rows[2][4] + "\t");
                Console.Write(dt.Rows[2][5] + "\t");
                Console.Write(dt.Rows[2][6] + "\t");
                Console.WriteLine(dt.Rows[2][7]);
            }


            catch (Exception e)
            {
                Console.WriteLine("Err.:" + e.Message);
            }
            finally
            {
                sqlcnn.Close();
            }
        }
    }
}

/*
 
Employee Salary Allowances for show specific rows

1St row (index:0),7 columns value
1006    aravi   10000   2000.000000     1500.000000     3500.000000     13500.000000    10000.000000

3rd row (index:0),7 columns value
1003    suthakar        70000   14000.000000    10500.000000    24500.000000    94500.000000    70000.000000    

*/