﻿using System;

 //Example for Call by Value And Call by References
 
namespace TCaa
{
    class CLSCBVCBRaa
    {
        public static void uSwap(int i,int j)
        {
            i = 5; j = 2;
            i = i + j;
            j = i - j;
            i = i - j;
            Console.WriteLine("Swap[i]" + i);
            Console.WriteLine("Swap[j]" + j);

        }
        public static void uExchange( ref int i,ref int j)
        {
            i = 4; j = 9;
            i = i + j;
            j = i - j;
            i = i - j;
            Console.WriteLine("Exchange[i]" + i);
            Console.WriteLine("Exchange[j]" + j);

        }

        public static void Main()
        {
            int a = 5, b = 2;
            int x = 4, y = 9;
            Console.WriteLine("before Swap[a]:" + a);
            Console.WriteLine("before Swap[b]:" + b);
            uSwap(a, b);
            Console.WriteLine("After Swap[b]:" + a);
            Console.WriteLine("After Swap[b]:" + b);

            Console.WriteLine("before Exchange[x]:" + x);
            Console.WriteLine("before Exchange[y]:" + y);
            uExchange(ref x, ref y);
            Console.WriteLine("After Exchange[x]:" + x);
            Console.WriteLine("After Exchange[y]:" + y);

        }


    }
}
/*
 OutPut:
 before Swap[a]:5
before Swap[b]:2
Swap[i]2
Swap[j]5
After Swap[b]:5
After Swap[b]:2
before Exchange[x]:4
before Exchange[y]:9
Exchange[i]9
Exchange[j]4
After Exchange[x]:9
After Exchange[y]:4
*/
