﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCaa
{
    public class CLSSTSelctaa
    {
        public static void Main()
        {
            DataCLSSTaaDataContext dc = new DataCLSSTaaDataContext(CLSSCnStr.forbalasdb);
            var ds = from row in dc.GetTable<CLSSTaa>()
                     select new
                     {
                         eid = row.eid,
                         ename = row.ename,
                         esal = row.esal,
                         tax10 = row.tax10,
                         tax20 = row.tax20,
                         tax30 = row.tax30,
                         taxtot = row.taxtot,
                         npay = row.npay
                     };
            Console.WriteLine("\n Salary tax Table has record \n ");
            foreach (var obj in ds)
            {
                Console.Write("{0,4}\t", obj.eid);
                Console.Write("{0,-5}", obj.ename);
                Console.Write("{0,12}", obj.esal);
                Console.Write("{0,12}", obj.tax10);
                Console.Write("{0,12}", obj.tax20);
                Console.Write("{0,12}", obj.tax30);
                Console.Write("{0,12}", obj.taxtot);
                Console.Write("{0,12}", obj.npay);
                Console.WriteLine("\n");

            }
        }
    }
}
/*
Output:
Salary tax Table has record

1001    x5      200000.00       0.000       0.000       0.000       0.000  200000.000

1002    x3      400000.00   25000.000       0.000       0.000   25000.000  375000.000

1003    x2      600000.00   25000.000  100000.000       0.000  125000.000  675000.000

1004    x4      800000.00   25000.000  100000.000       0.000  125000.000  875000.000

1005    x1     1000000.00   25000.000  100000.000       0.000  125000.000 1075000.000

1006    x9       90000.00       0.000       0.000       0.000       0.000   90000.000

1007    x9       90000.00       0.000       0.000       0.000       0.000   90000.000
*/
