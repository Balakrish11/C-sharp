﻿using System;
/*
namespace TCaa.accessspecifier
{
    class CLSASaa
    { 
    private int x;
    }

class CLSABab
{
    public static void Main()
    {
        CLSASaa aa = new CLSASaa();
            //Console.WriteLine(aa.x);
    }

}
       

}
*/