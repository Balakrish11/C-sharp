﻿using System;

namespace TCaa
{
    class TEyh
    {
        public static void Main()

        {
            String s = "5";
            int i = 0;
            try
            {
                i = int.Parse(s);

            }
            catch (Exception e)
            {
                i = 0;
                Console.WriteLine("err-1:" + e.Message);
            }
            Console.WriteLine(s + "-" + s.GetType());
            Console.WriteLine(i + "-" + i.GetType());
            s = "fox9";
            try
            {
                i = int.Parse(s);
            }
            catch (Exception e)
            {
                i = 0;
                Console.WriteLine("err-2:" + e.Message);
            }
            Console.WriteLine(s + "-" + s.GetType());
            Console.WriteLine(i + "-" + i.GetType());

        }
    }

}
