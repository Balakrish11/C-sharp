﻿using System;
namespace TCaa
{
    class CLSConsaa0
    {
        public CLSConsaa0()
        {
            Console.WriteLine("default Constructor");
        }
        public CLSConsaa0(int i)
        {
            Console.WriteLine("overload Constructor");
        }
        public CLSConsaa0(CLSConsaa0 tmpobj)
        {
            Console.WriteLine("copy Constructor");
        }
        ~CLSConsaa0()
            {
            Console.WriteLine("destructor");
            }
        }
    class CLSConsaa
    {
        public static void Main()
        {
            new CLSConsaa0();  
            CLSConsaa0 a= new CLSConsaa0(10);
            CLSConsaa0 b = new CLSConsaa0(a);
        }
    }

}
/*
OP:
default Constructor
overload Constructor
copy Constructor

destructor
destructor
destructor
*/