﻿using System;


namespace TCaa
{
    class Tcabs
    {
        public static void Main()
        {
            String s = "fox";
            int i = 0;
            int.TryParse(s, out i);
            Console.WriteLine(i + "-" + i.GetType());
            Console.WriteLine(s + "-"+s.GetType());

        }


    }

}

/*
  0-System.Int32
fox-System.String
Press any key to continue . . .
 */
