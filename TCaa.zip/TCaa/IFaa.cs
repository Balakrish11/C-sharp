﻿using System;

namespace TCaa
{
    class IFaa
    {
        public static void Main()
        {
            int i = 5, j = 9, k = 2;
            if(i>j && i<k)
            {
                Console.WriteLine("big number:" + i);
            }
            else if (j > k)
            {
                Console.WriteLine("big number:" + j);
            }
            else
            {
                Console.WriteLine("big number:" + k);
            }
        }
    }
/*
 Output:
 big number:9
Press any key to continue . . .
*/

}
