﻿using System;

namespace TCaa
{
    class SPac
    {
        public void udSum(int x,int y)
        {
            Console.WriteLine(x + y);
        }
        public static void udMinus(int x,int y)
        {
            Console.WriteLine(x - y);
        }
        public static void Main()
        {
            SPac spb = new SPac();
            spb.udSum(1, 9);
            SPac.udMinus(6, 3);
        }
    }
}
/*
10
3
Press any key to continue . . .
*/
